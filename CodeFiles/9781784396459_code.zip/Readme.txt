All the chapters are tested.

Chapter 2 does not have any code files.
Rest of the chapters have code files, which inlclude:

Chapter 1, 3, 4, 5, 6, 7, 8, 9, 10, and 11.